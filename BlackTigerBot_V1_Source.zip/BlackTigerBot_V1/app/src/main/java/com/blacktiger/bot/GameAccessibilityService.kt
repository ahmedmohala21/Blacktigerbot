package com.blacktiger.bot

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * نقطة تأسيس لخدمة إمكانية الوصول.
 * لا تنفذ نقرات تلقائية في هذه النسخة.
 * ستتم إضافة التعرف على شاشات اللعبة بعد معايرة الصور ومراجعة تدفق البناء.
 */
class GameAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // لاحقًا: رصد تغيّر الشاشة وقراءة النصوص الظاهرة بعد موافقة المستخدم.
    }

    override fun onInterrupt() {
        // إيقاف أي إجراء جارٍ عند مقاطعة الخدمة.
    }
}
